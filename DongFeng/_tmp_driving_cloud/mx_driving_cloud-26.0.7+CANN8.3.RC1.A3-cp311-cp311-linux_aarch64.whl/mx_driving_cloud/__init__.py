__all__ = [
    "SubMConv2d",
    "SparseConv2d",
    "SparseConv3d",
    "SparseInverseConv3d",
    "SparseConvTensor",
    "SparseModule",
    "SparseSequential",
    "unique_dim",
    "npu_max_pool2d",
    "futr3d_target_single",
    "refline_head_get_target_single",
    "grid_sampler3d_cloud",
    "nms_rotated",
    "npu_nms3d_filter",
    "dynamic_scatterC_cloud",
    "npu_dynamic_scatter_cloud",
    "scatter_max_v3_cloud",
    "batch_matmul_cloud",
    "linalg",
    "conv_bn_eval",
    "grid_sampler2d_cloud",
]

import os
import torch_npu
import mx_driving_cloud._C

from .modules.sparse_conv import SubMConv2d, SparseConv2d, SparseConv3d, SparseInverseConv3d
from .modules.sparse_modules import SparseConvTensor, SparseModule, SparseSequential
from .ops.unique_dim import unique_dim
from .ops.npu_max_pool2d import npu_max_pool2d
from .ops.refline_head_get_target_single import refline_head_get_target_single
from .ops.futr3d_target_single import futr3d_target_single
from .ops.grid_sampler3d_cloud import grid_sampler3d_cloud
from .ops.nms_rotated import nms_rotated
from .ops.nms3d_filter import nms3d_filter, boxes_iou_bev_v1
from .ops.npu_dynamic_scatter_cloud import npu_dynamic_scatter_cloud, dynamic_scatter_cloud
from .ops.scatter_max_v3_cloud import scatter_max_v3_cloud
from .ops.batch_matmul_cloud import batch_matmul_cloud
from .ops import linalg
from .ops.conv_bn_eval import conv_bn_eval
from .ops.grid_sampler2d_cloud import grid_sampler2d_cloud

def _set_env():
    mx_driving_root = os.path.dirname(os.path.abspath(__file__))
    mx_driving_opp_path = os.path.join(mx_driving_root, "packages", "vendors", "customize")
    ascend_custom_opp_path = os.environ.get("ASCEND_CUSTOM_OPP_PATH")
    ascend_custom_opp_path = (
        mx_driving_opp_path if not ascend_custom_opp_path else mx_driving_opp_path + ":" + ascend_custom_opp_path
    )
    os.environ["ASCEND_CUSTOM_OPP_PATH"] = ascend_custom_opp_path

    mx_driving_op_api_so_path = os.path.join(mx_driving_opp_path, "op_api", "lib", "libcust_opapi_cloud.so")
    mx_driving_cloud._C._init_op_api_so_path(mx_driving_op_api_so_path)


_set_env()
