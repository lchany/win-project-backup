# Copyright (c) 2024, Huawei Technologies.All rights reserved.
# Copyright 2019 Yan Yan
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import math

import numpy as np
import torch
from torch.nn import init
from torch.nn.init import calculate_gain
from torch.nn.parameter import Parameter

from ..ops import sparse_functional as Fsp
from .sparse_modules import SparseModule
from .sparse_structure import SparseConvTensor, IndiceData


def get_conv_output_size(input_size, kernel_size, stride, padding, dilation):
    ndim = len(input_size)
    output_size = []
    for i in range(ndim):
        size = (input_size[i] + 2 * padding[i] - dilation[i] *
                (kernel_size[i] - 1) - 1) // stride[i] + 1
        if kernel_size[i] == -1:
            output_size.append(1)
        else:
            output_size.append(size)
    return output_size


def _calculate_fan_in_and_fan_out_hwio(tensor):
    dimensions = tensor.ndimension()
    if dimensions < 2:
        raise ValueError("fan in and fan out can not be computed for tensor"
                         "with fewer than 2 dimensions")

    if dimensions == 2:  # Linear
        fan_in = tensor.size(-2)
        fan_out = tensor.size(-1)
    else:
        num_input_fmaps = tensor.size(-2)
        num_output_fmaps = tensor.size(-1)
        receptive_field_size = 1
        if tensor.dim() > 2:
            receptive_field_size = tensor[..., 0, 0].numel()
        fan_in = num_input_fmaps * receptive_field_size
        fan_out = num_output_fmaps * receptive_field_size

    return fan_in, fan_out


class SparseConvolution(SparseModule):
    # pylint: disable=too-many-arguments,huawei-too-many-arguments
    def __init__(
        self,
        ndim,
        in_channels,
        out_channels,
        kernel_size=3,
        stride=1,
        padding=0,
        dilation=1,
        groups=1,
        bias=True,
        subm=False,
        output_padding=0,
        transposed=False,
        inverse=False,
        indice_key=None,
        fused_bn=False,
        mode="mmcv",
    ):
        super().__init__()
        if groups != 1:
            raise RuntimeError("do not support group == 1")

        self.ndim = ndim
        self.kernel_size = self._standardize_param(kernel_size, ndim)
        self.stride = self._standardize_param(stride, ndim)
        self.padding = self._standardize_param(padding, ndim)
        self.dilation = self._standardize_param(dilation, ndim)
        self.output_padding = self._standardize_param(output_padding, ndim)

        self._validate_parameters()

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.conv1x1 = np.prod(self.kernel_size) == 1
        self.transposed = transposed
        self.inverse = inverse
        self.groups = groups
        self.subm = subm
        self.indice_key = indice_key
        self.fused_bn = fused_bn
        self.mode = mode

        self._init_weights_and_bias(bias)
        self.reset_parameters()
        self.trans_weight = False

    def _standardize_param(self, param, ndim):
        if not isinstance(param, (list, tuple)):
            return [param] * ndim
        return param

    def _validate_parameters(self):
        for d, s in zip(self.dilation, self.stride):
            if not any([s == 1, d == 1]):
                raise RuntimeError(
                    "Only one of stride or dilation can be greater than 1 per dimension.")

    def reset_parameters(self):
        fan_in, fan_out = _calculate_fan_in_and_fan_out_hwio(self.weight)
        if self.mode == "mmcv":
            init.kaiming_uniform_(self.weight, a=math.sqrt(5))
        else:
            self._custom_kaiming_uniform_(self.weight,
                                          a=math.sqrt(5),
                                          fan_in=fan_in,
                                          fan_out=fan_out)
        if self.bias is not None:
            if fan_in == 0:
                bound = 0
            else:
                bound = 1 / math.sqrt(fan_in)
            init.uniform_(self.bias, -bound, bound)

    def _custom_kaiming_uniform_(self,
                                 tensor,
                                 a=0,
                                 fan_in=0,
                                 fan_out=0,
                                 mode="fan_in",
                                 nonlinearity="leaky_relu"):
        fan = 0.0
        if mode == "fan_in":
            fan = float(fan_in)
        elif mode == "fan_out":
            fan = float(fan_out)
        gain = calculate_gain(nonlinearity, a)
        std = gain / math.sqrt(fan)
        bound = math.sqrt(3.0) * std
        with torch.no_grad():
            tensor.uniform_(-bound, bound)
            tensor.data = (tensor.data.reshape(self.out_channels,
                                               np.prod(self.kernel_size) *
                                               self.in_channels).transpose(-1, -2).contiguous())
            tensor.data = tensor.data.reshape(*self.kernel_size, self.in_channels,
                                              self.out_channels)

    def _init_weights_and_bias(self, bias):
        raise NotImplementedError

    def forward(self, input_):
        raise NotImplementedError

    def _get_output_spatial_shape(self, input_):
        if self.subm:
            out_spatial_shape = input_.spatial_shape
        else:
            out_spatial_shape = get_conv_output_size(input_.spatial_shape, self.kernel_size,
                                                     self.stride, self.padding, self.dilation)

        out_spatial_shape = [int(i) for i in out_spatial_shape]
        if not isinstance(out_spatial_shape, list):
            out_spatial_shape = out_spatial_shape.tolist()

        return out_spatial_shape

    def _create_output_tensor(self,
                              out_features,
                              outidx,
                              out_spatial_shape,
                              batch_size,
                              input_tensor=None):
        if self.bias is not None:
            out_features += self.bias

        out_tensor = SparseConvTensor(out_features, outidx, out_spatial_shape, batch_size)
        if input_tensor is not None and hasattr(input_tensor, 'indice_dict'):
            out_tensor.indice_dict = input_tensor.indice_dict.copy()
        return out_tensor


class SparseConvolution2D(SparseConvolution):
    def _init_weights_and_bias(self, bias):
        self.weight = Parameter(torch.Tensor(self.out_channels, *self.kernel_size,
                                             self.in_channels))
        if bias:
            self.bias = Parameter(torch.Tensor(self.out_channels))
        else:
            self.register_parameter("bias", None)

    def forward(self, input_):
        if not isinstance(input_, SparseConvTensor):
            raise RuntimeError("input_ is not SparseConvTensor")

        if self.mode == "mmcv" and not self.trans_weight:
            # [Cout,h,w,Cin] -> [h,w,Cin,Cout]
            self.weight.data = self.weight.data.permute(1, 2, 3, 0).contiguous()
            self.trans_weight = True

        out_spatial_shape = self._get_output_spatial_shape(input_)

        if self.subm:
            out_features, outidx, _ = Fsp.indice_subm_conv2d(input_.features, input_.indices,
                                                             self.weight, out_spatial_shape,
                                                             self.out_channels, input_.batch_size,
                                                             self.kernel_size, self.stride,
                                                             self.padding, self.dilation,
                                                             self.groups, self.bias)
        else:
            out_features, outidx = Fsp.indice_conv2d(input_.features, input_.indices, self.weight,
                                                     out_spatial_shape, self.out_channels,
                                                     input_.batch_size, self.kernel_size,
                                                     self.stride, self.padding, self.dilation,
                                                     self.groups, self.bias)

        return self._create_output_tensor(out_features, outidx, out_spatial_shape,
                                          input_.batch_size)


class SparseConvolution3D(SparseConvolution):
    def _init_weights_and_bias(self, bias):
        self.weight = Parameter(torch.Tensor(*self.kernel_size, self.in_channels,
                                             self.out_channels))
        if bias:
            self.bias = Parameter(torch.Tensor(self.out_channels))
        else:
            self.register_parameter("bias", None)

    def forward(self, input_):
        if not isinstance(input_, SparseConvTensor):
            raise RuntimeError("input_ is not SparseConvTensor")

        if self.inverse:
            indicedata = self._get_indice_data(input_)
            out_features = Fsp.indice_inverse_conv3d(input_.features, self.weight, self.in_channels,
                                                     self.out_channels, self.kernel_size,
                                                     indicedata)
            outidx = indicedata.origin_indices
            out_spatial_shape = indicedata.origin_spatial_shape
        else:
            out_spatial_shape = self._get_output_spatial_shape(input_)
            out_features, outidx, unique_indices_offset, sorted_idx_to_former_indices, outidx_pair = Fsp.indice_conv3d(
                input_.features, input_.indices, self.weight, out_spatial_shape, self.out_channels,
                input_.batch_size, self.kernel_size, self.stride, self.padding, self.dilation,
                self.groups, self.bias)

            if self.indice_key is not None:
                indicedata = IndiceData(input_.spatial_shape, input_.indices, unique_indices_offset,
                                        sorted_idx_to_former_indices, outidx_pair, False)
                if hasattr(input_, 'indice_dict'):
                    input_.indice_dict[self.indice_key] = indicedata
        out_tensor = self._create_output_tensor(out_features, outidx, out_spatial_shape,
                                                input_.batch_size, input_)

        if self.indice_key is not None and not self.inverse:
            out_tensor.indice_dict[self.indice_key] = indicedata

        return out_tensor

    def _get_indice_data(self, input_):
        if self.indice_key is None:
            raise ValueError("SparseInverseConv3d requires a non-None indice_key")
        if self.indice_key not in input_.indice_dict:
            raise RuntimeError(f"IndiceData not found with key: {self.indice_key}")
        return input_.indice_dict[self.indice_key]


class SparseConv2d(SparseConvolution2D):
    def __init__(
        self,
        in_channels,
        out_channels,
        kernel_size=2,
        stride=1,
        padding=0,
        dilation=1,
        groups=1,
        bias=False,
        indice_key=None,
        mode="mmcv",
    ):
        super().__init__(
            2,
            in_channels,
            out_channels,
            kernel_size,
            stride,
            padding,
            dilation,
            groups,
            bias,
            indice_key=indice_key,
            mode=mode,
        )


class SubMConv2d(SparseConvolution2D):
    def __init__(
        self,
        in_channels,
        out_channels,
        kernel_size,
        stride=1,
        padding=0,
        dilation=1,
        groups=1,
        bias=False,
        indice_key=None,
        mode="mmcv",
    ):
        super().__init__(
            2,
            in_channels,
            out_channels,
            kernel_size,
            stride,
            padding,
            dilation,
            groups,
            bias,
            True,
            indice_key=indice_key,
            mode=mode,
        )


class SparseConv3d(SparseConvolution3D):
    def __init__(
        self,
        in_channels,
        out_channels,
        kernel_size,
        stride=1,
        padding=0,
        dilation=1,
        groups=1,
        bias=True,
        indice_key=None,
        mode="mmcv",
    ):
        super().__init__(
            3,
            in_channels,
            out_channels,
            kernel_size,
            stride,
            padding,
            dilation,
            groups,
            bias,
            indice_key=indice_key,
            mode=mode,
        )


class SparseInverseConv3d(SparseConvolution3D):
    def __init__(
        self,
        in_channels,
        out_channels,
        kernel_size,
        stride=1,
        padding=0,
        dilation=1,
        groups=1,
        bias=True,
        indice_key=None,
        mode="mmcv",
    ):
        if in_channels % 8 != 0 or out_channels % 8 != 0:
            raise RuntimeError(f"Both in_channels and out_channels must be divisible by 8. "
                               f"Got in_channels={in_channels}, out_channels={out_channels}. ")
        if groups != 1 or dilation != 1:
            raise RuntimeError("Currently only supports groups=1 and dilation=1. "
                               f"Got groups={groups}, dilation={dilation}. ")
        super().__init__(
            3,
            in_channels,
            out_channels,
            kernel_size,
            stride,
            padding,
            dilation,
            groups,
            bias,
            inverse=True,
            indice_key=indice_key,
            mode=mode,
        )
