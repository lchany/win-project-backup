"""
Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.
"""
import torch
from torch.autograd import Function

import torch_npu
import numpy as np
import mx_driving_cloud._C


class NmsRotatedFunction(Function):
    @staticmethod
    def forward(ctx, boxes, scores, iou_threshold: float):
        if boxes.device.type != 'npu' or scores.device.type != 'npu':
            raise ValueError("Input boxes and scores must be on NPU")
        
        order = scores.sort(0, descending=True)[1]
        boxes = boxes[order].contiguous()
        keep, num_out = mx_driving_cloud._C.nms_rotated(boxes, iou_threshold)
        return order[keep[:num_out].long()].contiguous()

nms_rotated = NmsRotatedFunction.apply