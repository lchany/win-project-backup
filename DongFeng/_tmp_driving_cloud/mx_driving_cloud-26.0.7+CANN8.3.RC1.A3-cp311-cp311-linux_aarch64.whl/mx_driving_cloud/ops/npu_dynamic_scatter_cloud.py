"""
Copyright (c) OpenMMLab. All rights reserved.
Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.
Modification by: Huawei Developers
Modification date: 2025-11-20 
Modification Description: 
Modification 1. Add support for Ascend NPU
"""

from typing import Any, Optional, Tuple
import warnings

import torch
import torch_npu
from torch.autograd import Function
import numpy as np

import mx_driving_cloud._C


class DynamicScatterCloudFunction(Function):
    @staticmethod
    # 'pylint: disable=too-many-arguments,huawei-too-many-arguments
    def forward(
        ctx: Any, feats: torch.Tensor, coors: torch.Tensor, reduce_type: str = "max"
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        
        if (torch.numel(feats) == 0 or torch.numel(coors) == 0):
            raise Exception("Error! Input Tensor cannot be an empty tensor.\n")
        
        if reduce_type not in ("max", "sum", "mean"):
            raise ValueError("reduce_type should be 'max', 'sum' or 'mean', but now is %s." % reduce_type)

        coors_max_values = coors[:, 1:3].amax(dim=0)
        coors_max_y = coors_max_values[0] + 1
        coors_max_z = coors_max_values[1] + 1
        voxel_idx = coors[:,0]*coors_max_y*coors_max_z+coors[:,1]*coors_max_z+coors[:,2]

        import mx_driving._C
        num_voxels, uniqued_voxel_idx, prefix_sum_point_per_voxel, argsort_coor, indices = mx_driving._C.unique_voxel(
            voxel_idx
        )

        voxel_coors = coors[indices]
        
        voxel_feats, compare_mask = mx_driving_cloud._C.npu_dynamic_scatter_cloud(
            feats, coors, prefix_sum_point_per_voxel, argsort_coor, num_voxels, reduce_type
        )
        
        # add: deal with big voxel
        # 0. calculate points num of every voxel according to prefix_sum
        end_val = len(argsort_coor)
        prefix_sum_right = torch.cat((prefix_sum_point_per_voxel[1:], torch.tensor([end_val]).npu()))
        prefix_sum_left = prefix_sum_point_per_voxel
        point_num_per_voxel = prefix_sum_right - prefix_sum_left

        # 1. find big voxels ( pintNum > bigVoxelLength * alignedNum )
        bigVoxelLength = 125
        alignedNum = 8
        big_voxel_indices = torch.where(point_num_per_voxel > (bigVoxelLength * alignedNum))[0]

        # 2. find the start and end index of big voxel by big_voxel_indices
        for indice in big_voxel_indices:
            arg_sort_start = prefix_sum_point_per_voxel[indice]
            if indice < (len(prefix_sum_point_per_voxel) - 1) :
                arg_sort_end = prefix_sum_point_per_voxel[indice + 1]
            else : 
                arg_sort_end = len(coors)
            # 3. argsort_slice [arg_sort_start：arg_sort_end]
            argsort_slice = argsort_coor[arg_sort_start:arg_sort_end]

            # 4. get feats by argsort_slice
            single_voxel_feats = feats[argsort_slice]

            # 5. reduce
            if reduce_type == "max":
                single_voxel_feats_values,  single_voxel_feats_indices = torch.max(single_voxel_feats, dim=0, keepdim=True)
                single_voxel_feats_indices_dim0 = single_voxel_feats_indices[0]
                for i in range(len(single_voxel_feats_indices_dim0)):
                    single_argsort = argsort_slice[single_voxel_feats_indices_dim0[i].item()]
                    com_mask_index0 = single_argsort.item()
                    com_mask_index1 = i // 8
                    compare_mask[com_mask_index0][com_mask_index1] += 2 ** (i % 8)
            elif reduce_type == "mean":
                single_voxel_feats_values = torch.mean(single_voxel_feats, dim=0)
            else:
                single_voxel_feats_values = torch.sum(single_voxel_feats, dim=0)
            # 6. put reduce result to voxel_feats
            voxel_feats[indice] = single_voxel_feats_values
        ctx.reduce_type = reduce_type
        ctx.feats_shape = feats.shape
        ctx.save_for_backward(prefix_sum_point_per_voxel, argsort_coor, compare_mask, big_voxel_indices)
        ctx.mark_non_differentiable(voxel_coors)
        return voxel_feats, voxel_coors

    @staticmethod
    # 'pylint: disable=too-many-arguments,huawei-too-many-arguments
    # 'pylint: disable=too-many-return-arguments,huawei-too-many-return-arguments
    def backward(ctx: Any, grad_voxel_feats: torch.Tensor, grad_voxel_coors: Optional[torch.Tensor] = None) -> tuple:
        
        if (torch.numel(grad_voxel_feats) == 0 or torch.numel(grad_voxel_coors) == 0):
            raise Exception("Error! Input Tensor cannot be an empty tensor.\n")
        
        (prefix_sum_point_per_voxel, argsort_coor, compare_mask, big_voxel_indices) = ctx.saved_tensors
        grad_point_feats = torch.zeros(ctx.feats_shape, dtype=grad_voxel_feats.dtype, device=grad_voxel_feats.device)
        mx_driving_cloud._C.npu_dynamic_scatter_cloud_grad(
            grad_point_feats,
            grad_voxel_feats.contiguous(),
            prefix_sum_point_per_voxel,
            argsort_coor,
            compare_mask,
            ctx.reduce_type,
        )
        # deal the big voxel
        grand_vodel_feats_row_len = len(grad_voxel_feats[0])
        # 0. prepare for max
        if ctx.reduce_type == "max":
            bits_big = (2 ** torch.arange(8)).to(torch.int32).unsqueeze(0).npu()
            zeros_scalar = 0.0

            cal_bits_small = grand_vodel_feats_row_len % 8
            bits_small = bits_big
            if cal_bits_small > 0:
                bits_small = bits_big[0, 0 : cal_bits_small]

        for indice in big_voxel_indices:
            arg_sort_start = prefix_sum_point_per_voxel[indice]
            if indice < (len(prefix_sum_point_per_voxel) - 1) :
                arg_sort_end = prefix_sum_point_per_voxel[indice + 1]
            else : 
                arg_sort_end = len(grad_point_feats)
            # 1. argsort_slice [arg_sort_start:arg_sort_end]
            argsort_slice = argsort_coor[arg_sort_start:arg_sort_end]

            # 2. find the grad_point_feats by argsort_slice, and put it into grad_voxel_feats
            if ctx.reduce_type == "max":
                is_nonzero = (compare_mask[argsort_slice] != 0)
                has_nonzero_element = torch.any(is_nonzero, dim=1)
                mask_argsort_slice = argsort_slice[torch.where(has_nonzero_element)[0]]
                grad_voxel_feats[indice]
                for single_mask_argsort in mask_argsort_slice:
                    compare_mask_row = compare_mask[single_mask_argsort]
                    compare_mask_row_len = len(compare_mask_row)
                    bits = bits_big
                    for i in range(compare_mask_row_len):
                        grad_voxel_feats_start = i * 8
                        if i == (compare_mask_row_len -1):
                            bits = bits_small
                            grad_voxel_feats_end = grand_vodel_feats_row_len
                        else:
                            grad_voxel_feats_end = grad_voxel_feats_start + 8
                        binary_mask = (torch.bitwise_and(compare_mask_row[i], bits) > 0)
                        part_grad_point_feats = torch.where(binary_mask, grad_voxel_feats[indice][grad_voxel_feats_start:grad_voxel_feats_end], zeros_scalar)
                        grad_point_feats[single_mask_argsort][grad_voxel_feats_start:grad_voxel_feats_end] = part_grad_point_feats

            elif ctx.reduce_type == "mean":
                grad_point_feats[argsort_slice] = grad_voxel_feats[indice] / argsort_slice.numel()
                
            else:
                grad_point_feats[argsort_slice] = grad_voxel_feats[indice]

        return grad_point_feats, None, None


dynamic_scatter_cloud = DynamicScatterCloudFunction.apply


def npu_dynamic_scatter_cloud(feats, coors, reduce_type='max'):
    warnings.warn(
        "`npu_dynamic_scatter_cloud` will be deprecated in future. Please use `dynamic_scatter_cloud` instead.",
        DeprecationWarning,
    )
    return DynamicScatterCloudFunction.apply(feats, coors, reduce_type)
