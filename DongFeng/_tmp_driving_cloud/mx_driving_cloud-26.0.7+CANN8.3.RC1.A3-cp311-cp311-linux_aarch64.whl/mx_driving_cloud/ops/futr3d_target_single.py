from typing import Optional

import torch
import torch_npu
from torch.autograd import Function

import mx_driving_cloud._C


class Futr3dTargetSingle(Function):
    @staticmethod
    def forward(
        ctx,
        pos_inds,
        pos_assigned_gt_inds,
        pos_gt_bboxes,
        bbox_pred,
        gt_bboxes,
        gt_labels,
        num_classes,
        code_size,
        dist_loss_weight=False,
        has_train_label_weights=False,
        train_label_weights=None,
    ) -> tuple:
        out = mx_driving_cloud._C.futr3d_target_single(
            pos_inds,
            pos_assigned_gt_inds,
            pos_gt_bboxes,
            bbox_pred,
            gt_bboxes,
            gt_labels,
            num_classes,
            code_size,
            dist_loss_weight,
            has_train_label_weights,
            train_label_weights
        )
        return out

futr3d_target_single = Futr3dTargetSingle.apply