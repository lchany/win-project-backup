"""
Copyright (c) OpenMMLab. All rights reserved.
Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.
Modification by: Huawei Developers
Modification date: 2025-12-01
Modification Description: 
Modification 1. Add support for Ascend NPU
"""

import torch
import torch_npu
from torch.autograd import Function

import mx_driving_cloud._C


class ScatterMaxV3CloudFunction(Function):
    @staticmethod
    def forward(ctx, updates, indices, out=None):
        func = mx_driving_cloud._C.scatter_max_v3_cloud
        out = func(updates, indices, out)
        return out

scatter_max_v3_cloud = ScatterMaxV3CloudFunction.apply
