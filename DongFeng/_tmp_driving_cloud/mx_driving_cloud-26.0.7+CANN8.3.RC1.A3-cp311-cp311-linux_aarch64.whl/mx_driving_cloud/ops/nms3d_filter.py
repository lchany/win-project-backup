"""
Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.
"""
import torch
from torch.autograd import Function
import numpy as np
import torch_npu
import mx_driving_cloud._C
import time
class Nms3dFilterFunction(Function):
    @staticmethod
    def forward(ctx, boxes, scores, iou_threshold: float):
        if boxes.device.type != 'npu':
            raise ValueError("Input boxes must be on NPU")

        if scores.device.type != 'npu':
            raise ValueError("Input scores must be on NPU") 

        order = scores.sort(0, descending=True)[1]
        boxes = boxes[order].contiguous()

        keep, num_out = mx_driving_cloud._C.nms3d_filter(boxes, iou_threshold)
        return order[keep[:num_out].long()].contiguous()


nms3d_filter = Nms3dFilterFunction.apply
npu_nms3d_filter = Nms3dFilterFunction.apply

def boxes_iou_bev_v1(boxes_a, boxes_b, aligned=False):
    if aligned and boxes_a.shape[0] != boxes_b.shape[0]:
        raise ValueError("When aligned=True, boxes_a and boxes_b must have the same shape.")

    format_flag = 3
    unit_flag  = 0
    clockwise = True
    mode_flag = 1
    margin = 1e-2
    import mx_driving._C
    return mx_driving._C.npu_boxes_overlap_bev(boxes_a, boxes_b, format_flag, unit_flag, clockwise, mode_flag, aligned, margin)