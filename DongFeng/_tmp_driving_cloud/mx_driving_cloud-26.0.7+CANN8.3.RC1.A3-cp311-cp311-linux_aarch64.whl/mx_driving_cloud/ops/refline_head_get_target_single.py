import torch
import torch_npu
from torch.autograd import Function

import mx_driving_cloud._C

class ReflineHeadGetTargetSingle(Function):
    @staticmethod
    def forward(
        ctx, 
        bbox_pred,
        gt_bboxes,
        pts_pred, 
        gt_labels,
        pos_assigned_gt_inds,
        pos_inds,  
        gt_shifts_pts,
        gt_routes_vecs_valid,
        pos_gt_bboxes,
        route_class_num,
        order_index = None,
    ) -> torch.Tensor:
        out = mx_driving_cloud._C.refline_head_get_target_single(
            bbox_pred,
            gt_bboxes,
            pts_pred,  
            gt_labels,
            pos_assigned_gt_inds,
            pos_inds,  
            gt_shifts_pts,
            gt_routes_vecs_valid,
            pos_gt_bboxes,
            route_class_num,
            order_index,
        )
        return out

refline_head_get_target_single = ReflineHeadGetTargetSingle.apply