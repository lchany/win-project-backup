"""
Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.
"""
import torch
import torch_npu
from torch.autograd import Function



def check(projection_mat, pts_extend):
    if projection_mat.dtype != torch.float32 or pts_extend.dtype != torch.float32:
        return False
    if projection_mat.dim() < 4 or projection_mat.dim() > 6:
        return False
    if pts_extend.dim() < 4 or pts_extend.dim() > 6:
        return False
    m_shape = projection_mat.shape
    e_shape = pts_extend.shape
    m1, m2 = m_shape[-2], m_shape[-1]
    e1, e2 = e_shape[-2], e_shape[-1]
    if m1 == 3 and m2 == 3 and e1 == 3 and e2 == 1:
        return True
    if m1 == 4 and m2 == 4 and e1 == 4 and e2 == 1:
        return True
    return False

def batch_matmul_cloud(projection_mat, pts_extend):
    if check(projection_mat, pts_extend):
        m_shape = projection_mat.shape
        e_shape = pts_extend.shape
        m_dim = len(m_shape)
        e_dim = len(e_shape)
        target_dim = max(m_dim, e_dim)
        m_shape_out = (1,) * (target_dim - m_dim) + tuple(m_shape)
        e_shape_out = (1,) * (target_dim - e_dim) + tuple(e_shape)
        if target_dim > m_dim:
            projection_mat = projection_mat.reshape(m_shape_out)
        if target_dim > e_dim:
            pts_extend = pts_extend.reshape(e_shape_out)
        import mx_driving
        result = mx_driving.npu_batch_matmul(projection_mat, pts_extend)
    else:
        result = torch.matmul(projection_mat, pts_extend)
    return result