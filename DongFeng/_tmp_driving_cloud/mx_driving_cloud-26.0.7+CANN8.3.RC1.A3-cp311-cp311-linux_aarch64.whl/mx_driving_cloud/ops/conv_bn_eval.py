"""
Copyright (c) OpenMMLab. All rights reserved.
Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.
Modification by: Huawei Developers
Modification date: 2026-01-29
Modification Description: 
Modification 1. Add support for Ascend NPU
"""

import torch
import torch_npu
from torch.autograd import Function
import mx_driving_cloud._C


class ConvBnEvalFunction(Function):
    @staticmethod
    def forward(ctx, running_var, bias_on_the_fly, bn_weight, bn_bias, running_mean, weight_on_the_fly, eps):
        func = mx_driving_cloud._C.conv_bn_eval
        out = func(running_var, bias_on_the_fly, bn_weight, bn_bias, running_mean, weight_on_the_fly, eps)
        return out

conv_bn_eval = ConvBnEvalFunction.apply
