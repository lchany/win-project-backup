# Copyright (c) 2024, Huawei Technologies.All rights reserved.
# Copyright 2019 Yan Yan
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import Any

import numpy as np
import torch
from torch.autograd import Function
from torch.nn import functional as F
from torch.autograd.function import once_differentiable

import mx_driving_cloud._C


class SparseConv2dFunction(Function):
    @staticmethod
    # pylint: disable=too-many-arguments,huawei-too-many-arguments
    def forward(
        ctx: Any,
        features,
        indices,
        weight,
        out_spatial_shape,
        out_channels,
        batch_size,
        kernel_size,
        stride,
        padding,
        dilation,
        groups,
        bias,
    ) -> torch.Tensor:

        device = features.device
        weight = weight.data

        # calculate the index pair
        if (features.shape[1] % 8 != 0):
            raise Exception("Error! in_channel must be divisible by 8.\n")

        import mx_driving
        outidx_pair, ouidx_offset = mx_driving_cloud._C.npu_sparse_conv2d(
            indices, kernel_size, stride, padding, out_channels, out_spatial_shape, batch_size)

        # sort and nonezero
        num_voxels_, uni_voxels, unique_indices_offset, sorted_idx_to_former_indices, uni_argsort_indices = mx_driving.unique_voxel(
            ouidx_offset)
        indices_last = torch.tensor(ouidx_offset.shape).to(unique_indices_offset.device)
        unique_indices_offset = torch.cat((unique_indices_offset, indices_last), dim=0)

        # index_put and matmul
        out_features, outidx = mx_driving_cloud._C.multi_to_sparse_2d(
            features, weight, unique_indices_offset.int(), sorted_idx_to_former_indices.int(),
            outidx_pair.int())

        outidx = outidx[:, 0:3]

        ctx.save_for_backward(features, weight, sorted_idx_to_former_indices.int(),
                              unique_indices_offset.int())
        return out_features, outidx


def generate_map2d(coors, origin_spatial_shape, bs, kernel_size):
    spatial_shape = (origin_spatial_shape[0] + 2 * (kernel_size[0] // 2),
                     origin_spatial_shape[1] + 2 * (kernel_size[1] // 2))
    padding = kernel_size[0] // 2
    spatial_shape_size = spatial_shape[0] * spatial_shape[1]
    sparse_rate = coors.shape[0] / (spatial_shape_size * bs)
    flatten_indices = (coors[:, 0] * spatial_shape_size + coors[:, 1] * (spatial_shape[1]) +
                       coors[:, 2])

    flatten_indices += (spatial_shape[1] + 1) * padding
    map1 = torch.full((spatial_shape_size * bs, ), -1, dtype=torch.int32, device=coors.device)

    map1[flatten_indices] = torch.arange(flatten_indices.numel(),
                                         dtype=torch.int32,
                                         device=coors.device)
    map2 = torch.Tensor([]).int()
    # [batch, h, w] -> [batch, h , w, 0]
    coors = F.pad(coors, (0, 1))
    return map1, map2, spatial_shape, coors, sparse_rate


class SubMConv2dFunction(Function):
    @staticmethod
    # pylint: disable=too-many-arguments,huawei-too-many-arguments
    def forward(
        ctx: Any,
        features,
        indices,
        weight,
        out_spatial_shape,
        out_channels,
        batch_size,
        kernel_size,
        stride,
        padding,
        dilation,
        groups,
        bias,
    ) -> torch.Tensor:
        weight = weight.data
        map1, map2, spaned_spatial_shape, new_indices, sparse_rate = generate_map2d(
            indices, out_spatial_shape, batch_size, kernel_size)
        output_iml2col, indices_offset = mx_driving_cloud._C.npu_subm_sparse_conv2d(
            features, new_indices, map1, map2, kernel_size, features.shape[1], spaned_spatial_shape,
            batch_size, sparse_rate)
        out_features = output_iml2col @ weight.reshape(-1, out_channels)
        ctx.kernel_size = kernel_size
        ctx.save_for_backward(features, weight, output_iml2col, indices_offset)
        return out_features, indices, indices_offset


class SparseConv3dFunction(Function):
    @staticmethod
    # pylint: disable=too-many-arguments,huawei-too-many-arguments
    def forward(
        ctx: Any,
        features,
        indices,
        weight,
        out_spatial_shape,
        out_channels,
        batch_size,
        kernel_size,
        stride,
        padding,
        dilation,
        groups,
        bias,
    ) -> torch.Tensor:

        device = features.device
        weight = weight.data

        # calculate the index pair
        import mx_driving
        outidx_pair, ouidx_offset = mx_driving._C.npu_sparse_conv3d(indices, kernel_size, stride,
                                                                    padding, out_channels,
                                                                    out_spatial_shape, batch_size)

        # sort and nonezero
        num_voxels_, uni_voxels, unique_indices_offset, sorted_idx_to_former_indices, uni_argsort_indices = mx_driving.unique_voxel(
            ouidx_offset)
        indices_last = torch.tensor(ouidx_offset.shape).to(unique_indices_offset.device)
        unique_indices_offset = torch.cat((unique_indices_offset, indices_last), dim=0)

        # index_put and matmul
        out_features, outidx = mx_driving._C.multi_to_sparse_v2(features, weight,
                                                                unique_indices_offset.int(),
                                                                sorted_idx_to_former_indices,
                                                                outidx_pair)
        outidx, outidx_ = torch.chunk(outidx, 2, dim=1)

        ctx.save_for_backward(features, weight, sorted_idx_to_former_indices,
                              unique_indices_offset.int())

        return out_features, outidx, unique_indices_offset, sorted_idx_to_former_indices, outidx_pair

    @staticmethod
    @once_differentiable
    # pylint: disable=too-many-return-values
    def backward(ctx: Any,
                 grad_out_features: torch.Tensor,
                 grad_outidx=None,
                 grad_unique_indices_offset=None,
                 grad_sorted_idx_to_former_indices=None,
                 grad_outidx_pair=None) -> tuple:
        features, weight, sorted_idx_to_former_indices, unique_indices_offset = ctx.saved_tensors
        import mx_driving
        feature_grad, weight_grad = mx_driving._C.npu_sparse_conv3d_grad(
            unique_indices_offset, sorted_idx_to_former_indices, features, weight,
            grad_out_features)

        return feature_grad, None, weight_grad, None, None, None, None, None, None, None, None, None


class SparseInverseConv3dFunction(Function):
    @staticmethod
    # pylint: disable=too-many-arguments,huawei-too-many-arguments
    def forward(
        ctx: Any,
        features,
        weight,
        in_channels,
        out_channels,
        kernel_size,
        indicedata,
    ) -> torch.Tensor:

        weight = weight.data
        output_img2col = mx_driving_cloud._C.npu_sparse_inverse_conv3d(
            features, indicedata.origin_indices, indicedata.unique_indices_offset.int(),
            indicedata.sorted_idx_to_former_indices, kernel_size, in_channels)

        out_features = output_img2col @ weight.reshape(-1, out_channels)
        ctx.save_for_backward(weight, indicedata.unique_indices_offset.int(),
                              indicedata.sorted_idx_to_former_indices, indicedata.outidx_pair,
                              output_img2col)
        return out_features

    @staticmethod
    @once_differentiable

    # pylint: disable=too-many-return-values
    def backward(ctx: Any, grad_out_features: torch.Tensor) -> tuple:
        weight, unique_indices_offset, sorted_idx_to_former_indices, outidx_pair, output_img2cols = ctx.saved_tensors
        weight_shape = weight.shape
        weight.data = weight.data.permute(0, 1, 2, 4, 3).contiguous()
        import mx_driving
        inverse_feature_grad, outidx = mx_driving._C.multi_to_sparse_v2(
            grad_out_features, weight, unique_indices_offset, sorted_idx_to_former_indices,
            outidx_pair)
        inverse_weight_grad = (grad_out_features.transpose(0, 1).contiguous() @ output_img2cols)

        inverse_weight_grad = inverse_weight_grad.transpose(0, 1).contiguous().view(
            weight_shape[0], weight_shape[1], weight_shape[2], weight_shape[3], weight_shape[4])

        return inverse_feature_grad, inverse_weight_grad, None, None, None, None


indice_conv2d = SparseConv2dFunction.apply
indice_subm_conv2d = SubMConv2dFunction.apply
indice_conv3d = SparseConv3dFunction.apply
indice_inverse_conv3d = SparseInverseConv3dFunction.apply
