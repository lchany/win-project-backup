from typing import Any, Tuple, Optional, Union

import torch
import torch_npu
from torch.autograd import Function
import mx_driving_cloud._C

SMALL_SIZE = 5500

def check_int32_mul_overflow(a, b):
    # Check for positive overflow
    if b != 0 and a > torch.iinfo(torch.int32).max / b:
        return False
    # Check for negative overflow (underflow)
    elif b != 0 and a < torch.iinfo(torch.int32).min / b:
        return False
    else:
        return True


def valid_mapping(a, b, c):
    if not check_int32_mul_overflow(a, b):
        return False
    mul = a * b
    if not check_int32_mul_overflow(mul, c):
        return False
    return True

class UniqueDimFunc(Function):
    @staticmethod
    def forward(ctx, input, *args):
        """Core unique operation implementation for NPU acceleration"""
        # Validate input parameters
        if not isinstance(input, torch.Tensor):
            raise ValueError("input must be torch.Tensor")
        sorted = args[0] if len(args) > 0 else True
        return_inverse = args[1] if len(args) > 1 else False
        return_counts = args[2] if len(args) > 2 else False
        dim = args[3] if len(args) > 3 else None
        if not isinstance(sorted, bool):
            raise ValueError("sorted must be bool")
        if not isinstance(return_inverse, bool):
            raise ValueError("return_inverse must be bool")
        if not isinstance(return_counts, bool):
            raise ValueError("return_counts must be bool")
        if dim is not None and not isinstance(dim, int):
            raise ValueError("dim must be int or None")

        # Reject empty inputs
        if input.numel() == 0:
            raise ValueError("Input tensor cannot be empty")

        if input.dim() >= 1 and input.shape[0] <= SMALL_SIZE:
            return torch.unique(input,
                                sorted=sorted,
                                return_inverse=return_inverse,
                                return_counts=return_counts,
                                dim=dim)

        # If sorted is Fasle, use torch.unique
        if sorted == False:
            return torch.unique(input,
                                sorted=sorted,
                                return_inverse=return_inverse,
                                return_counts=return_counts,
                                dim=dim)

        # Special case for NPU acceleration
        if (input.dim() == 2 and input.shape[1] == 3 and  # Nx3 tensor
            not return_counts and dim == 0 and input.shape[0] <= torch.iinfo(torch.int32).max and
            input.dtype == torch.int32 and input.min().item() >= 0):
            intput_max = torch.amax(input, 0)
            input_max_x = intput_max[0].item() + 1
            input_max_y = intput_max[1].item() + 1
            input_max_z = intput_max[2].item() + 1

            if not valid_mapping(input_max_x, input_max_y, input_max_z):
                return torch.unique(input,
                                    sorted=sorted,
                                    return_inverse=return_inverse,
                                    return_counts=return_counts,
                                    dim=dim)
            input = input.npu()
            point1d = mx_driving_cloud._C.unique_mapping(input, input_max_x, input_max_y, input_max_z)
            output, inverseIndices = mx_driving_cloud._C.unique_voxel_cloud(input, point1d)

            if not return_inverse:
                return output
            
            return output, inverseIndices
        
        # Fallback to PyTorch native
        return torch.unique(input,
                          sorted=sorted,
                          return_inverse=return_inverse,
                          return_counts=return_counts,
                          dim=dim)

def unique_dim(input, sorted=True, return_inverse=False, return_counts=False, dim=None):
    """User-friendly unique operation with NPU acceleration support
    
    Args:
        input: torch.Tensor - Input tensor to process
        sorted: bool - Whether to sort unique values (default: True)
        return_inverse: bool - Return inverse indices (default: False)
        return_counts: bool - Return value counts (default: False)
        dim: Optional[int] - Dimension to operate on (default: None)
    
    Returns:
        Union[torch.Tensor, Tuple] - Unique values and optionally inverse indices/counts
    
    Raises:
        ValueError: If input is not a torch.Tensor, parameters have invalid types, 
                   or input tensor is empty
    """
    return UniqueDimFunc.apply(input, sorted, return_inverse, return_counts, dim)
